# appliance repair abilene tx

Website for appliance repair abilene tx, specializing in Appliance Repair .

## Files included

- 15 pages in the root folder (`404.html`, `about.html`, `appliance-repair-downtown-abilene.html`, `appliance-repair-north-abilene.html`, `appliance-repair-southwestern-abilene.html`, `contact.html`, `dishwasher-repair.html`, `dryer-repair.html`, `index.html`, `locations.html`, `oven-repair.html`, `privacy-policy.html`, `refrigerator-repair.html`, `services.html`, `washer-repair.html`)
- `blog/` - 2 pages
- `assets/` - stylesheet, scripts and images
- `.htaccess`
- `_redirects`
- `netlify.toml`
- `robots.txt`
- `sitemap.xml`
- `vercel.json`

## Setup

1. Upload everything in this folder to your web host
2. Keep the files in the site's root directory
3. **Shared/cPanel hosting:** make sure `.htaccess` uploaded too. It starts with a
   dot, so file managers hide it by default — turn on "show hidden files" and
   confirm it sits next to `index.html`. Without it every page except the
   homepage returns 404.
4. Open the site and check the pages, links and contact details

Generated with RankLocal.